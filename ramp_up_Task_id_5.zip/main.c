/******************************************************************************

Author : Ahmed Soliman 

Task : Task_id_005 

RR Academy

*******************************************************************************/
#include <stdio.h>
#include"Print_Max_Min.h"

#define SIZE 4

int Arr[SIZE] = {2,-5,10,4};

int main()
{
     PrintMinMax(Arr, 4);

    return 0;
    
    
}

