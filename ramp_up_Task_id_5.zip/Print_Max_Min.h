#ifndef _PRINT_MAX_MIN_H_
#define _PRINT_MAX_MIN_H_


void PrintMinMax(int Arr[], int arrSize);













#endif 